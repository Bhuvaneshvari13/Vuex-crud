<template>
    <div class="employee-card">
      <h2>Employee Table</h2>
      <div class="top-section">
        
        <div class="showbuttons">
                                    <!-- Inline Add / Cancel buttons -->
  <template v-if="addingRow">
    <button @click="submitAllInlineEmployees">Add to Table</button>
    <button @click="cancelInlineEmployee">Cancel</button>
  </template>

  <template v-else>
    <button  v-if="!addingRow && editingId === null && !showGetEmployee" @click="startInlineAdd" >
      Add Employee
    </button> 

    <button v-if="editingId === null && !showGetEmployee && !addingRow && !isSingleRecord" @click="toggleGetEmployee">
      Get Employee
    </button>
    <button v-if="isSingleRecord" @click="resetTable">Show All</button>

    <button v-if="editingId === null && !showGetEmployee && !addingRow" :disabled="selectedIds.length !== 1" @click="enableEdit">Update</button>
    <button v-if="editingId !== null && !showGetEmployee" @click="saveUpdate" style="margin-right:5px">Save Changes</button>
    <button v-if="editingId !== null && !showGetEmployee" @click="cancelEdit">Cancel</button>

    <button v-if="editingId === null && !showGetEmployee && !addingRow" :disabled="!canDelete" @click="deleteSelectedEmployees">Delete</button>
    
    <!-- GET-EMPLOYEE DISPLAY -->
<div v-if="showGetEmployee" class="get-employee-container">
  <input type="number" v-model.number="employeeId" placeholder="Enter Employee ID"/>
  <button @click="getEmployeeInTable">Submit</button>
  <button @click="cancelGetEmployee">Close</button>
</div>

  </template>
</div>
</div>  <!--top section div closing tag-->

<ColumnFilter :columns="columns" :modelValue="visibleColumns" @update:modelValue="visibleColumns = $event"/>
<div class="utility-bar">
<div class="search-box">
  <label>Find employees:</label>
  <input type="text" placeholder="Search employees..."  @input="onSearch"/>
</div>
</div>

<!-- TABLE -->
<div class="bottom-section">
<table border="1">
 <thead>
  <tr ref="headerRow">
    <th class="fixed-col"> <input type="checkbox" v-model="selectAll" @change="toggleSelectAll"/></th>  
    <!-- fixec-col class for  mentioning in filter to prevent that column from draggable -->
    <th v-for="col in displayedColumns" :key="col.key" v-bind:data-key="col.key" :style="{ width: columnWidths[col.key] + 'px' }">   <!--data-key = bridge bw DOM and Vue  ---for sortableJs -->
      {{ col.label }}
      
      <span class="sort-arrow" @click="sortBy(col.key,'asc')">▲</span>
      <span class="sort-arrow" @click="sortBy(col.key,'desc')">▼</span>

      <InlineFilter
        v-if="col.key === 'position'"
        v-bind:items="uniquePositions"
        @filter-change="onPositionFilterChange"
      />

  <span class="resize-handle" @mousedown="startResize($event, col.key)"></span>
  </th>
  </tr>
</thead>

<tbody>
<!-- empty in line add row -->
<tr v-for="row in newInlineEmployees" :key="row">
  <td><button @click="addAnotherInlineRow">+</button></td>
  <td><input type="number" v-model.number="row.id"/></td>
  <td><input type="text" v-model="row.name" /></td>
  <td><input type="email" v-model="row.email" /></td>
  <td><input type="number" v-model.number="row.salary" /></td>
  <td><input type="text" v-model="row.position" /></td>
</tr>    

<tr v-for="emp in sortedEmployees" :key="emp.id">
  <td><input type="checkbox" :value="emp.id" v-model="selectedIds" 
      :disabled="editingId !== null && editingId !== emp.id" 
      @change="matchHeaderSelectAll"/>
  </td>
  
  <!-- switch bw read mode and edit mode -->
  <td v-for="col in displayedColumns" :key="col.key" :style="{ width: columnWidths[col.key] + 'px' }">
    <template v-if="editingId === emp.id">
    <input
      v-model="editEmployee[col.key]"
      :type="col.key ==='salary'? 'number' : 'text'"
    />
    </template>

    <template v-else>
       {{ emp[col.key] }}
    </template>
  </td>
</tr>
</tbody>

</table>

<DownloadTable
   v-bind:tableData="sortedEmployees"        
   v-bind:displayedColumns="displayedColumns" 
/>

<div v-if="$store.state.loading">Please wait</div>
<div v-if="$store.state.error" style="color:red;">Wrong input: {{$store.state.error}}</div>
</div>

</div>

</template>

<script>
import InlineFilter from '@/components/InlineFilter.vue';
import ColumnFilter from '@/components/ColumnFilter.vue';
import DownloadTable from '@/components/DownloadTable.vue';
import Sortable from 'sortablejs';

export default {
  name:'employeeTable',

  components:{
    InlineFilter,
    ColumnFilter,
    DownloadTable,
  },

data() {
  return {
    //addingRow: false,  // shows inline add row
    //newInlineEmployee: { id: null, name: '', email: '', salary: null, position: '' },
    addingRow: false,
    newInlineEmployees: [],  //inline add



    selectedIds: [],   //for checkbox --common
    selectAll: false,  //checkbox

    employeeId: null,         //for get employee by id
    showGetEmployee: false,

    isSingleRecord: false,    //for get employee   

    editingId: null,          // id set for editable row
    editEmployee: null,      //editing 

    sortKey: null,
    sortOrder: 'asc',    //for sorting

    selectedPositions: [],

    columns: [                       //for columnComponent component
      { key: 'id', label: 'ID' },   //key used for data, label used for display
      { key: 'name', label: 'Name' },
      { key: 'email', label: 'Email' },
      { key: 'salary', label: 'Salary' },
      {key: 'position', label: 'Position' },
    ],
    
    visibleColumns: ['id', 'name', 'email', 'salary', 'position'],

    columnWidths: {
      id: 80,
      name: 120,
      email: 180,
      salary: 120,
      position: 120
    },

    resizing: {
      active: false,
      key: null,
      startX: 0,
      startWidth: 0
    },
    
    };
  },

computed:{
  canDelete() {
    return this.selectedIds.length > 0;   //check box conditions
   },
   
  sortedEmployees() {   //
   let list = [...this.$store.getters.filteredEmployees];


if (this.selectedPositions.length > 0) {
  list = list.filter(emp =>
    this.selectedPositions.includes(emp.position)
  );
}

  if (!this.sortKey) return list;

  for (let i = 0; i < list.length - 1; i++) {
    for (let j = 0; j < list.length - i - 1; j++) {
      let a = list[j][this.sortKey];
      let b = list[j + 1][this.sortKey];

      if (
        (this.sortOrder === 'asc' && a > b) ||
        (this.sortOrder === 'desc' && a < b)
      ) {
        [list[j], list[j + 1]] = [list[j + 1], list[j]]; // swap
      }
    }
  }
  return list;
},

  uniquePositions() {      //computed property that stores only unique value by filtering--avoid redundant data
  const result = [];
  this.$store.state.employees.forEach(emp => {
    if (!result.includes(emp.position)) {
      result.push(emp.position);
    }
  });
  return result;
},

  displayedColumns() {                     //return only the selected column.
    return this.columns.filter(col =>
    this.visibleColumns.includes(col.key)
    );
  }

},

  mounted() {
    this.$store.dispatch('fetchEmployees');  // calls Vuex action

    Sortable.create(this.$refs.headerRow, {
    animation: 150,
    direction: 'horizontal',
    filter: '.fixed-col,input, button, span', // prevents drag from filter/sort icons and fixed-col class
    preventOnFilter: false,

     onMove: (evt) => {
    return !evt.related.classList.contains('fixed-col');
  },

    onEnd: this.onColumnDrop
  });
  },

  
methods: {
  //  addInlineRow() {
  //   this.addingRow = true;
  //   this.newInlineEmployee = { id: null, name: '', email: '', salary: null, position: '' };
    
  // },

  async submitInlineEmployee() {
    await this.$store.dispatch('addEmployee', this.newInlineEmployee);
    this.addingRow = false;
    this.newInlineEmployee = { id: null, name: '', email: '', salary: null, position: '' };
  },

  cancelInlineEmployee() {
    this.addingRow = false;
    this.newInlineEmployee = { id: null, name: '', email: '', salary: null, position: '' };
  },           //add emplyee funtions


    async getEmployeeInTable() {     
      if (!this.employeeId) {
        alert('Please enter an Employee ID');
        return;
        }
        const employee = await this.$store.dispatch('getEmployeeById',this.employeeId);
        if (!employee) {
          return;
          }

  // showing in employee in table
  this.$store.commit('SET_EMPLOYEES', [employee]);
  this.isSingleRecord = true;
},
   
resetTable() {   //setting to normal table after get single record.
  this.employeeId = null;
  this.isSingleRecord = false;
  this.showGetEmployee=false;
  this.$store.dispatch('fetchEmployees');
},

toggleGetEmployee() {
  this.showGetEmployee = !this.showGetEmployee; // toggle true/false
  if (this.showGetEmployee) {
    this.isSingleRecord = false; // reset table state
    this.editingId = null;
    this.selectedIds = [];
    this.selectAll = false;

  }
},

deleteSelectedEmployees() {
  if (!this.selectedIds.length) return;

  this.selectedIds.forEach(id => {
    this.$store.dispatch('deleteEmployee', id);
  });

  this.selectedIds = [];  // reset checkboxes.
  this.selectAll = false;  //resetting the header
},

toggleSelectAll() {
  
    if (this.selectAll) {
      this.selectedIds = this.$store.state.employees.map(e => e.id);
    }
    else {
      this.selectedIds = [];
    }
  },

matchHeaderSelectAll() { // header-check box is selected only if no.of selected rows === total number of rows.
    this.selectAll =this.selectedIds.length === this.$store.state.employees.length;
  },

enableEdit(){           //UPDATE button: onclick marks the row as editable

  if (this.selectedIds.length === 0) return;
  this.editingIds = [...this.selectedIds];
  
  const emp = this.$store.state.employees.find(
    e => e.id === this.selectedIds[0]  //only one id is selected and that id is always present at index-0.
  );

  if (!emp) return;

 this.editingId = emp.id;
 this.editEmployee = {
  name: emp.name,
  email: emp.email,
  salary: emp.salary,
  position: emp.position,
  id: emp.id
};


},

saveUpdate() {
  if (!this.editEmployee) return;

  this.$store.dispatch('updateEmployee', this.editEmployee);

  // reset UI state
  this.editingId = null;
  this.editEmployee = null;
  this.selectedIds = [];
  this.selectAll = false;
},

cancelEdit() {
  this.editingId = null;
  this.editEmployee = null;
  this.selectedIds = [];
},

sortBy(key,order) {
  this.sortKey = key;
  this.sortOrder = order;
},

onPositionFilterChange(values) {
  console.log('Selected positions:', values);
  this.selectedPositions = values;
},

startResize(e, key) {
  this.resizing.active = true;
  this.resizing.key = key;
  this.resizing.startX = e.clientX; //horizontal start position of mouse
  this.resizing.startWidth = this.columnWidths[key];

  document.addEventListener('mousemove', this.onResize);
  document.addEventListener('mouseup', this.stopResize);
},

onResize(e) {
  if (!this.resizing.active) return;

  const delta = e.clientX - this.resizing.startX;
  const width = this.resizing.startWidth + delta;

  // minimum width protection
  this.columnWidths[this.resizing.key] = Math.max(width, 60);
},

stopResize() {
  this.resizing.active = false;
  this.resizing.key = null;

  document.removeEventListener('mousemove', this.onResize);
  document.removeEventListener('mouseup', this.stopResize);
},

onColumnDrop(evt) {
    const oldIndex = evt.oldIndex - 1; // minus checkbox column
    const newIndex = evt.newIndex - 1;

    if (oldIndex < 0 || newIndex < 0) return;

    const moved = this.columns.splice(oldIndex, 1)[0];
    this.columns.splice(newIndex, 0, moved);
  },

  cancelGetEmployee() {
  this.employeeId = null;
  this.showGetEmployee = false;
  this.isSingleRecord = false;
  this.selectedIds = [];
  this.selectAll = false;
  this.$store.dispatch('fetchEmployees');
},

onSearch(event) {
    this.$store.commit('SET_SEARCH_QUERY', event.target.value);
  },

startInlineAdd() {
  this.addingRow = true;
  this.newInlineEmployees = [
    {
      id: null,
      name: '',
      email: '',
      salary: null,
      position: ''
    }
  ];
},

addAnotherInlineRow() {
  this.newInlineEmployees.unshift({
    id: null,
    name: '',
    email: '',
    salary: null,
    position: ''
  });
},

async submitAllInlineEmployees() {
  await this.$store.dispatch('bulkCreateEmployees',this.newInlineEmployees);
  this.exitInlineAddMode();
},

cancelInlineAdd() {
  this.exitInlineAddMode();
},

exitInlineAddMode() {
  this.addingRow = false;
  this.newInlineEmployees = [];
}
  }
}
</script>

<style scoped>
table {
  border-collapse: collapse;
  table-layout:fixed;
 
  
}
th, td {
  padding: 12px 12px;
  text-align: center;
  position:relative;
  white-space: normal;       /* maintains normal white spaces */
  word-break: break-word;    /*tries to wrap word wise */
  overflow-wrap: break-word; 
}

.showbuttons{
  display: flex;
  flex-direction: row;
  gap:0.5rem;
  margin-bottom: 10px;
  padding: 12px 12px;
  /* border: 1px solid #d1d5db; */
  background: #ffffff;
  font-size: 14px;
}
.showbuttons button:hover {
  cursor: pointer;
  background: #062680;
}
.showbuttons button:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
.showbuttons button {
  background: #2563eb;
  color: white;
  border-color: #2563eb;
}

.bottom-section {
  padding: 16px;
}

.get-employee-container {
  display: flex;
  gap: 12px;
  margin-bottom: 10px;
}

.sort-arrow {
  cursor: pointer;
  margin-left: 4px;
}

.resize-handle {
  position: absolute;
  right: 0;
  top: 0;
  width: 6px;
  height: 100%;
  cursor: col-resize;
  user-select: none;
}

.resize-handle:hover {
  background-color: rgb(223, 132, 132)
}

td input{
  width:100%;
  box-sizing: border-box;
}

.employee-card {
  background: #ffffff;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.utility-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 16px 0;
  margin-left: 13px;
  margin-bottom: 3px;

}

.search-box input {
  width: 240px;
  padding: 6px 10px;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  margin-top: 13px;
}
</style>
