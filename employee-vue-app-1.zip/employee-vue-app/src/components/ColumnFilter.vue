<template>
  <div class="column-filter">
    <button class="btn" @click="toggle">Column Filter</button>

    <div v-if="visible" class="popup">
      <div v-for="col in columns" :key="col.key">
        <label>
          <input
            type="checkbox"
            :value="col.key"
            v-model="localSelection"
            @change="emitChange"
          />
          {{ col.label }}
        </label>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ColumnFilter',

  props: {
    columns: {
      type: Array,
      required: true
    },
    modelValue: {   //visible column from parent
      type: Array,
      required: true
    }
  },

  data() {
    return {
      visible: false,
      localSelection: [...this.modelValue]
    };
  },

  methods: {
    toggle() {  //for column filter-pop-box
      this.visible = !this.visible;
    },

    emitChange() {
      this.$emit('update:modelValue', this.localSelection);
    }
  },

};
</script>

<style scoped>

.btn{
  background: #2563eb;
  color: white;
  border-color: #2563eb;
  margin-left: 13px;
  margin-bottom: 2px;
}
.popup{
  display: flex;
  flex-direction: row;
  background-color: rgb(255, 255, 255);
  width:auto;
  margin-left: 13px;
  z-index: 1;
  position: absolute;
}

</style>
