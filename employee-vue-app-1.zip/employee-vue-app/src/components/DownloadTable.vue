<template>
<div class="download-button">
  <button @click="downloadExcel">Download as Excel</button>
   <button @click="downloadPDF">Download PDF</button>
   </div>
</template>

<script>
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export default {
  name: "DownloadTable",

  props: {
    tableData:{ 
        type: Array,
        required: true 
    }, // rows to export
                   
    displayedColumns:{ 
        type: Array,
        required: true 
    }                // columns to export
  },

  methods: {
    
    downloadExcel() {
  // Prepare the data to export
  const rows = this.tableData.map(emp => {
    return this.displayedColumns.reduce((obj, col) => {
      obj[col.label] = emp[col.key]; // xcel column header -> value
      return obj;
    }, {});
  });

  // Create Excel sheet and workbook
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Employees");

  // Save the file
  XLSX.writeFile(workbook, "employees.xlsx");
},

  downloadPDF() {
    // Create a new PDF document
    const doc = new jsPDF();

    // Create table headers
    const headers = this.displayedColumns.map(col => col.label);

    // Create table rows
    const rows = this.tableData.map(emp =>
      this.displayedColumns.map(col => emp[col.key])
    );

    //  Generate table inside PDF
    autoTable(doc, {
      head: [headers],
      body: rows
    });

    // Download the PDF
    doc.save("employees.pdf");
  }

  }
};
</script>

<style scoped>
.download-button{
  display: flex;
  flex-direction: row;
  gap:0.5rem;
  margin-top: 10px;
  justify-content: center;

}
</style>