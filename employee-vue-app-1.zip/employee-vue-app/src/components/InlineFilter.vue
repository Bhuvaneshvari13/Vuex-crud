<template>
   <div class="filter-wrapper">
    <button @click="toggle">Filter By Value</button>

    <div v-if="visible" class="filter-popup">
        <button @click="selectAll">Select All</button>
        <button @click="clearAll"> Clear All</button>
      <div v-for="item in items" :key="item">
        <label>
            <input type="checkbox" v-bind:value="item" v-model="selected" @change="emitChange"/>{{item}}</label>
      </div>
    </div>
  </div>
</template>


<script>
export default {
  name: 'InlineFilter',

  data() {
  return {
    visible: false,
    selected:[]   // check box values -->for position column alone
  };
},

methods: {
  toggle() {
    this.visible = !this.visible;
  },

   emitChange() {
    this.$emit('filter-change',this.selected);  //emit used because child sends data to parent
  },

  clearAll(){
    this.selected=[];
    this.$emit('filter-change',this.selected);
  },

  selectAll() {
  this.selected = [...this.items];
  this.$emit('filter-change', this.selected);
}

},

props:{
    items:{
        type:Array,
        required:true
    }
},


};
</script>

<style scoped>
.filter-wrapper {
  position: relative;
  display: inline-block;
}

.filter-popup {
  position:absolute;
  text-align: left;
  background: rgb(223, 244, 247);
  border: 1px solid #4e5f03;
  padding: 8px;
  margin-top: 4px;
  z-index: 100;
  width: 150px;
}

</style>