import { createStore } from 'vuex';
import {
  fetchEmployeesAPI,
  addEmployeeAPI,
  updateEmployeeAPI,
  deleteEmployeeAPI,
  getEmployeeByIdAPI,
  bulkCreateEmployeesAPI,
} from '../services/employeeService';

const state = {
  employees: [],
  loading: false,
  error: null,
  searchQuery: '',
};

const mutations = {
  setEmployees(state, employees) {
    state.employees = employees;
  },
  addEmployee(state, employee) {
    state.employees.push(employee);
  },
  updateEmployee(state, updatedEmployee) {
    const index = state.employees.findIndex(e => e.id === updatedEmployee.id); //return -1 if false, 1 if true
    if (index !== -1) {
      state.employees[index] = updatedEmployee;
    }
  },
  removeEmployee(state, employeeId) {
    state.employees = state.employees.filter(e => e.id !== employeeId);
  },
  setLoading(state, status) {
    state.loading = status;
  },
  setError(state, error) {
    state.error = error;
  },

  SET_EMPLOYEES(state, employees) {
  state.employees = employees;
},
  
   SET_SEARCH_QUERY(state, query) {
    state.searchQuery = query;
  }

};

const actions = {

  async getEmployeeById({ commit }, employeeId) {
  commit('setLoading', true);
  commit('setError', null);

  try {
    const res = await getEmployeeByIdAPI(employeeId);
    const employee = res.data.data.getEmployeeTable;

    if (!employee) {
      commit('setError', 'Employee not found');
      return null;
    }

    return employee;
  } catch (err) {
    commit('setError', err.message);
    return null;
  } finally {
    commit('setLoading', false);
  }
},


  async fetchEmployees({ commit }) {
    commit('setLoading', true);
    commit('setError', null);
    try {
      const res = await fetchEmployeesAPI();
      commit('setEmployees', res.data.data.listEmployeeTables.items);
      console.log(res.data.data.listEmployeeTables.items);
    } catch (err) {
      commit('setError', err.message);
    } finally {
      commit('setLoading', false);
    }
  },

  async addEmployee({ commit }, employee) {
    commit('setLoading', true);
    commit('setError', null);
    try {
      const res = await addEmployeeAPI(employee);
      const created = res.data.data.createEmployeeTable;
      if (!created) {
        commit('setError', 'Employee ID already exists');
        return;
      }
      commit('addEmployee', created);
    } catch (err) {
      commit('setError', err.message);
    } finally {
      commit('setLoading', false);
    }
  },

  async updateEmployee({ commit }, employee) {
    commit('setLoading', true);
    try {
      const res = await updateEmployeeAPI(employee);
      const updated = res.data.data.updateEmployeeTable;
      if (!updated) {
        commit('setError', 'Update failed');
        return;
      }
      commit('updateEmployee', updated);
    } catch (err) {
      commit('setError', err.message);
    } finally {
      commit('setLoading', false);
    }
  },

 async upsertEmployee({ commit, state }, employee) {
  commit('setLoading', true);
  commit('setError', null);

  try {
    const res = await upsertEmployeeAPI(employee);
    const result = res.data.data.upsertEmployeeTable;

    if (!result) {
      commit('setError', 'Upsert failed: No data returned');
      return;
    }

    const exists = state.employees.some(e => e.id === result.id);

    if (exists) {
      commit('updateEmployee', result);
    } else {
      commit('addEmployee', result);
    }

  } catch (err) {
    commit('setError', err.message);
  } finally {
    commit('setLoading', false);
  }
},

  async deleteEmployee({ commit }, employeeId) {
    commit('setLoading', true);
    commit('setError', null);
    try {
      const res = await deleteEmployeeAPI(employeeId);
      const deleted = res.data.data.deleteEmployeeTable;
      if (!deleted) {
        commit('setError', 'Employee not found');
        return;
      }
      commit('removeEmployee', employeeId);
    } catch (err) {
      commit('setError', err.message);
    } finally {
      commit('setLoading', false);
    }
  },

  async bulkCreateEmployees({ commit }, employees) {
  commit('setLoading', true);
  commit('setError', null);

  try {
    const res = await bulkCreateEmployeesAPI(employees);
    const createdEmployees =
      res.data.data.bulkCreateEmployeeTable;

    if (!createdEmployees || !createdEmployees.length) {
      commit('setError', 'Bulk create failed');
      return;
    }

    createdEmployees.forEach(emp => {
      commit('addEmployee', emp);
    });

  } catch (err) {
    commit('setError', err.message);
  } finally {
    commit('setLoading', false);
  }
}

  
};

const getters ={
  
  filteredEmployees(state) {
    if (!state.searchQuery) {
      return state.employees;
    }

    const q = state.searchQuery.toLowerCase();

    return state.employees.filter(emp =>
      emp.name.toLowerCase().includes(q) ||
      emp.email.toLowerCase().includes(q) ||
      emp.position.toLowerCase().includes(q) ||
      String(emp.id).includes(q)
    );
  }

}


export default createStore({
  state,
  mutations,
  actions,
  getters
});


