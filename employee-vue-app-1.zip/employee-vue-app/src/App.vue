<template>
  <div id="app">
    <employee-Table></employee-Table>
  </div>
</template>

<script>
import employeeTable from './components/employeeTable.vue';

export default {
  components: { employeeTable }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  margin: 20px;
}
</style>
