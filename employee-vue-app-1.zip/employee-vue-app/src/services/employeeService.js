import axios from 'axios';

const apiClient = axios.create({
  baseURL:
    'https://r3nsqydmhnaivdu7wep5ptofvi.appsync-api.eu-north-1.amazonaws.com/graphql',
  headers: {
    'x-api-key': 'da2-c4w2xfrl6jbttmi7yhtxhuorry',
    'Content-Type': 'application/json'
  }
}
);

export const getEmployeeByIdAPI = (employeeId) => {
  return apiClient.post('', {
    query: `
      query GetEmployee($id: Int!) {
        getEmployeeTable(id: $id) {
          id
          name
          email
          salary
          position
        }
      }
    `,
    variables: {
      id: employeeId
    }
  });
};

export const fetchEmployeesAPI = () => {
  return apiClient.post('', {
    query: `
      query {
        listEmployeeTables {
          items {
            id
            name
            email
            salary
            position
          }
        }
      }
    `
  });
};

export const addEmployeeAPI = (employee) => {
  return apiClient.post('', {
    query: `
      mutation CreateEmployee($input: CreateEmployeeTableInput!) {
        createEmployeeTable(input: $input) {
          id
          name
          email
          salary
          position
        }
      }
    `,
    variables: { input: employee }
  });
};

export const updateEmployeeAPI = (employee) => {
  return apiClient.post('', {
    query: `
      mutation UpdateEmployee($input: UpdateEmployeeTableInput!) {
        updateEmployeeTable(input: $input) {
          id
          name
          email
          salary
          position
        }
      }
    `,
    variables: { input: employee }
  });
};

export const upsertEmployeeAPI = (employee) => {
  return apiClient.post('', {
    query: `
     mutation MyMutation {
  upsertEmployeeTable(
    input: {id: "", email: "", name: "", position: "", salary: 10}
  ) {
    email
    id
    name
    position
    salary
  }
}
    `,
    variables: { input: employee }
  });
};


export const deleteEmployeeAPI = (employeeId) => {
  return apiClient.post('', {
    query: `
      mutation DeleteEmployee($input: DeleteEmployeeTableInput!){
      deleteEmployeeTable(input: $input) {id}
      }
    `,
    variables: { input: { id: employeeId } }
  });
};

export const bulkCreateEmployeesAPI = (employee) => {
  return apiClient.post('', {
    query: `
      mutation BulkCreateEmployeeTable(
        $inputs: [BulkCreateEmployeeInput!]!
      ) {
        bulkCreateEmployeeTable(inputs: $inputs) {
          id
          name
          email
          salary
          position
        }
      }
    `,
    variables: {
      inputs: employee
    }
  });
};

